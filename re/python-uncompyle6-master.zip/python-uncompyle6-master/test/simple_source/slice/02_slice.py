ary = [1,2,3]
ary[:2]
ary[2:]
