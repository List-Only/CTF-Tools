# Tests:

#   ifstmt ::= testexpr _ifstmts_jump
#   _ifstmts_jump ::= c_stmts_opt JUMP_FORWARD COME_FROM

if True:
    b = False
