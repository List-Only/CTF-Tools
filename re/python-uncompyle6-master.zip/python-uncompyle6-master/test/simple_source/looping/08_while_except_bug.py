# From python 3.4 contextlib
# JUMP_BACK in while causes a problem
while exit_callbacks:
    try:
        if cb:
            exc_details = 5
    except:
        exc_details = new_exc_details
pass
