while __name__ != '__main__':
    b = 4
