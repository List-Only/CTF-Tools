def x0():
    pass

def x1(a):
    pass


def x2(a=5):
    pass

def x3(a, b, c=5):
    pass

def x4(a, b=5, **c):
    pass
