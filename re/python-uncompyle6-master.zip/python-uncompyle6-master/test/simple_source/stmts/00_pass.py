# Tests:
# assign ::= expr designator
pass
