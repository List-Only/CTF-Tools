# Tests:
# assign ::= expr designator

a = 'None'
b = None
c = 556
