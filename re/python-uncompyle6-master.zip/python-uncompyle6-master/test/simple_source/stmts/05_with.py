from __future__ import with_statement
with (sys) as f:
    print(f)
