def fn(var1, var2):
    return f'interpolate {var1} strings {var2} py36'


fn('a', 'b')