def fn(var):
    return f'interpolate {var} strings'