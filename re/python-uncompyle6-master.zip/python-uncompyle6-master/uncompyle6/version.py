# This file is suitable for sourcing inside bash as
# well as importing into Python
VERSION='2.8.2'
