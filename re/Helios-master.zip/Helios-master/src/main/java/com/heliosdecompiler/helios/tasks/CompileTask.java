package com.heliosdecompiler.helios.tasks;

public class CompileTask {
}
