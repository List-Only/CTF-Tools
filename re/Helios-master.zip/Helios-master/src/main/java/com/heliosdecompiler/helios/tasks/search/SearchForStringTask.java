package com.heliosdecompiler.helios.tasks.search;

import com.heliosdecompiler.helios.LoadedFile;

public class SearchForStringTask implements Runnable {
    @Override
    public void run() {

    }
}
