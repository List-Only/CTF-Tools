package com.heliosdecompiler.helios.api.events.requests;

public class RefreshViewRequest {
}
